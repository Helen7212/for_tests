import "./app.css";
import { Layout } from "./layout/layout";


export const App = () => {
  return (
     <Layout/>
  );
};

