import { Footer } from "../footer/footer";
import { Header } from "../header/header";
import  Demo  from "../grid/grid";
import { StyledEngineProvider } from '@mui/material/styles';

import styles from "./layout.module.css";

export const Layout = ({ sidebar }) => {
  return (
    <div className={styles.root}>
      <Header />
      <main className={styles.main}>
  <StyledEngineProvider injectFirst>
    <Demo />
  </StyledEngineProvider>,
        {sidebar}
      </main>
      <Footer />
    </div>
  );
};
