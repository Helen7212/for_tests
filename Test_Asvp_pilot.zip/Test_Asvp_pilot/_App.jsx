import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
//import { Box, Button, Menu, MenuItem } from '@mui/material'; 
import './App.css'
//import notFound from '.app/not-found.jsx'

function App() {
  const [count, setCount] = useState(0)
const [anchor, setAnchor] = useState(null); 
const options = ["First", "Second", "Third", "Fourth"]; 
const [selected, setSelected] = useState(-1); 
const openMenu = (event) => { setAnchor(event.currentTarget); }; 
const closeMenu = () => { setAnchor(null); }; 
const onMenuItemClick = (event, index) => { setAnchor(null); setSelected(index); }; 
  return (
    <div className="container">
            <ul className="menu">
                <li><a href="#">Программы</a>
   <ul className="sub-menu">
   <li><a href="#">Sub-Menu 1</a></li>
   <li><a href="#">Sub-Menu 2</a></li>
   <li><a href="#">Sub-Menu 3</a></li>
   <li><a href="#">Sub-Menu 4</a></li>
   <li><a href="#">Sub-Menu 5</a></li>   
   </ul>    
   </li>            
                <li><a href="#">Управление качеством</a></li>
                <li><a href="#">Справочники</a>
   <ul className="sub-menu">
   <li><a href="#">Спровочник материалов</a></li>
   <li><a href="#">Организационная структура</a></li>
   <li><a href="#">Справочник персонала</a></li>
   <li><a href="#">КСУ</a></li>
   </ul> 
   </li>                
                <li><a href="#">Дополнительные окна</a></li>
                <li><a href="#">Отчеты</a></li>
                <li><a href="#">Настройкм</a></li>
                <li><a href="#">О программе</a></li>
            
            </ul>

        
<div className="containerBloc" >
    <div className="box-1">
        <div className="box-menu"><span id="textMenu">Письма-заказы</span></div>
    </div>
    <div className="box-2">
        <div className="box-menu"><span id="textMenu">Документы</span></div>
    </div>
    <div className="box-3">
        <div className="box-menu"><span id="textMenu">Подробно</span></div>
    </div>
    <div className="box-4">
        <div className="box-menu"><span id="textMenu">Извещения</span></div>
    </div>
    <div className="col"> 
      <div className="box-5">
         <div className="box-menu"><span id="textMenu">Работы письма-заказа</span></div>
      </div>
    </div>    
</div>
      
        <footer className="footer">
            <p>© 2025 ОКБМ Африкантов</p>
        </footer>
    </div>
  )
}

export default App
