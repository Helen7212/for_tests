import "./app.css";

import { Layout } from "./components/layout/layout";
//import { Provider } from "react-redux";
//import { store } from "../../redux/store";
//import { BrowserRouter, Navigate, Route, Routes } from "react-router";
import { HomePage } from "./pages/homePage";
 //    <HomePage/>

 
export const App = () => {
  return (
    <div>
     <Layout />

    </div>
  );
};