import styles from "./footer.module.css";

export const Footer = () => {
  return <footer className={styles.footer}>2025 ОКБМ Африкантов</footer>;
};
