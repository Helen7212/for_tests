import {MainMenu} from "../mainMenu/mainMenu";
import styles from "./header.module.css";

export const Header = () => {
  return (
    <header className={styles.header}>
      <div className={styles.rightSection}>
        <MainMenu />
      </div>
    </header>
  );
};
