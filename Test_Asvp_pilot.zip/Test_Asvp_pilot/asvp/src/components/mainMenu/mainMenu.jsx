import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import './mainMenu.css';

export const MainMenu = () => {
  const [isOpen, setOpen] = useState(false);
  return (
    <header className='header'>      
    <button className='menu-button' onClick={()=> setOpen(!isOpen)}> Меню </button> 
     <nav className={`menu ${isOpen ? "active" : ""}`}>  
       <ul className='menu__list'>
           <li className='menu__item'> Программы 
              <ul className='submenu__list'>
                  <li className='submenu__item'> Маршрутная ведомость </li>
                  <li className='submenu__item'> Изделия в производстве  </li>                                 
              </ul>      
           </li>        
           <li className='menu__item'> Управление качеством </li>                                 
           <li className='menu__item'> Справочники 
              <ul className='submenu__list'>
                  <li className='submenu__item'> Материалы </li>
                  <li className='submenu__item'> КСУ  </li>                                 
                  <li className='submenu__item'> Подразделения </li>
                  <li className='submenu__item'> Персонал </li>
              </ul>   
           </li>               
           <li className='menu__item'> Дополнительные окна </li>
           <li className='menu__item'> Отчеты </li>
           <li className='menu__item'> Настройки пользователя </li>
       </ul>
     </nav>  
     </header>   
)
}

