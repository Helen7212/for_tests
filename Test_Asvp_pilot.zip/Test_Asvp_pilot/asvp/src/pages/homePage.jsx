//import { Link } from "react-router";

export const HomePage = () => {
  return (
      <div>АСВП</div>
  );
};
