import styles from "./footer.module.css";

export const Footer = () => {
  return <footer className={styles.footer}>ОКБМ Африкантов</footer>;
};
