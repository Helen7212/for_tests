import { Footer } from "../footer/footer";
import { Header } from "../header/header";

import styles from "./layout.module.css";

export const Layout = ({ sidebar }) => {
  return (
    <div className={styles.root}>
      <Header />
      <main className={styles.main}>
        {sidebar}
      </main>
      <Footer />
    </div>
  );
};
