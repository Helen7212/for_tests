export const Codec = ({ type }) => {
  return <span>{type}</span>;
};
