export const User = ({ name }) => {
  return <span>{name}</span>;
};
