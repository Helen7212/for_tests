import { Link } from "react-router";

export const HomePage = () => {
  return (
    <div>
      <div>Home Page</div>
      <Link to='/headphones'>to headhones</Link>
    </div>
  );
};
